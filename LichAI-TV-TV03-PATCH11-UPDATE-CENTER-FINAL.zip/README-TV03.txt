LỊCH AI TV #03 - UPDATE CENTER

Thay đúng các file theo đường dẫn trong gói này.

QUAN TRỌNG - thứ tự phát hành:
1. Build TV #03 (versionCode 3 / TV 1.2.0).
2. Upload APK mới với tên LichAI-TV-Release.apk vào Release cố định LichAITV.
3. Kiểm tra https://lich.ai.vn/download/tv tải đúng APK TV #03.
4. SAU CÙNG mới đưa tv-update.json trong gói này lên root repo.

Không đưa tv-update.json versionCode 3 lên trước khi APK TV #03 sẵn sàng, nếu không TV #02 sẽ báo cập nhật quá sớm.

Downloader code cố định: 1293077
