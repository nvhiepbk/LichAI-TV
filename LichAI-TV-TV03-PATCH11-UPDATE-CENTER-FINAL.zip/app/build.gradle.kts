plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "vn.ai.lich.tv"
    compileSdk = 36

    defaultConfig {
        applicationId = "vn.ai.lich.tv"
        minSdk = 26
        targetSdk = 36
        versionCode = 3
        versionName = "TV 1.2.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    signingConfigs {
        create("release") {
            val storeFilePath = System.getenv("LICHAI_TV_KEYSTORE_PATH")
            if (!storeFilePath.isNullOrBlank()) {
                storeFile = file(storeFilePath)
                storePassword = System.getenv("LICHAI_TV_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("LICHAI_TV_KEY_ALIAS")
                keyPassword = System.getenv("LICHAI_TV_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.leanback:leanback:1.2.0")
    implementation("androidx.tvprovider:tvprovider:1.1.0")
}
